<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['email'];
include('connexion.php');

$sql_fetch_user = "SELECT * FROM accounts WHERE email='$email'";
$result_user = $conn->query($sql_fetch_user);

if ($result_user->num_rows > 0) {
    $row = $result_user->fetch_assoc();
    $role = $row['role'];

    if ($role !== 'etudiant') {
        header("Location: unauthorized.php"); 
        exit();
    }
}

$id_etudiant = $row['id']; // L'ID de l'étudiant connecté

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $champ_modifié = $_POST['champ_modifié'];
    $nouvelle_valeur = $_POST['nouvelle_valeur'];

    // Insérer la demande de modification dans la base de données
    $sql_insert = "INSERT INTO modifs_en_attente (id_etudiant, champ_modifié, nouvelle_valeur) VALUES ('$id_etudiant', '$champ_modifié', '$nouvelle_valeur')";
    if ($conn->query($sql_insert) === TRUE) {
        echo "Demande envoyée avec succès !";
    } else {
        echo "Erreur : " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include('index.css'); ?>
</head>

<body>

    <div class="wrapper">
        <?php include('sidenav.php'); ?>

        <div class="main-panel">
            <?php include('navtop.php'); ?>

            <br />

            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="content">
                                    <h3>Demander une modification de profil</h3>
                                    <form method="POST" action="">
                                        <label for="champ_modifié">Champ à modifier :</label>
                                        <select name="champ_modifié" id="champ_modifié" class="form-control">
                                            <option value="nom">Nom</option>
                                            <option value="prenom">Prénom</option>
                                            <!-- Ajoute d'autres champs ici -->
                                        </select>

                                        <label for="nouvelle_valeur">Nouvelle valeur :</label>
                                        <input type="text" name="nouvelle_valeur" id="nouvelle_valeur" class="form-control" required />

                                        <button type="submit" class="btn btn-success">Envoyer la demande</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php include('footer.php'); ?>

        </div>
    </div>

</body>
<?php include('index.js'); ?>

</html>
