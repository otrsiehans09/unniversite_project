<footer class="footer" style="text-align: center;">
    <div class="container-fluid" style="text-align: center;">

        <p class="copyright" style="text-align: center;">
            Copyright &copy; 2024 Tous droits réservés.
        </p>
    </div>
</footer>