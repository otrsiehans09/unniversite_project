<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_nom = $_POST['nom'];
    $new_prenom = $_POST['prenom'];
    $new_email = $_POST['email'];
    
    $sql_update = "UPDATE enseignant SET nom='$new_nom', prenom='$new_prenom', email='$new_email' WHERE id='$enseignant_id'";
    if ($conn->query($sql_update) === TRUE) {
        echo "<div class='success'>Profil mis à jour !</div>";
    } else {
        echo "<div class='error'>Erreur : " . $conn->error . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier le Profil</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: #333;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        form {
            background: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 500px;
            animation: fadeIn 0.6s ease-out;
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #4e54c8;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }

        input[type="text"],
        input[type="email"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 6px;
            transition: border 0.3s ease;
        }

        input:focus {
            border-color: #764ba2;
            outline: none;
        }

        button {
            width: 100%;
            background: #4e54c8;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        button:hover {
            background: #3f45a2;
            transform: translateY(-2px);
        }

        .success {
            background-color: #2ecc71;
            color: white;
            padding: 10px;
            margin-bottom: 20px;
            text-align: center;
            border-radius: 5px;
        }

        .error {
            background-color: #e74c3c;
            color: white;
            padding: 10px;
            margin-bottom: 20px;
            text-align: center;
            border-radius: 5px;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 600px) {
            form {
                padding: 25px;
            }
        }
    </style>
</head>
<body>

    <form method="POST">
        <h2>Mettre à jour le profil</h2>

        <label for="nom">Nom :</label>
        <input type="text" name="nom" required>

        <label for="prenom">Prénom :</label>
        <input type="text" name="prenom" required>

        <label for="email">Email :</label>
        <input type="email" name="email" required>

        <button type="submit">Mettre à jour</button>
    </form>

</body>
</html>
