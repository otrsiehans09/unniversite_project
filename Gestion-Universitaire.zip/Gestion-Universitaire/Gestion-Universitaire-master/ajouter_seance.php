<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

include('connexion.php');

$email = $_SESSION['email'];
$sql_fetch_user = "SELECT * FROM accounts WHERE email='$email'";
$result_user = $conn->query($sql_fetch_user);

if ($result_user->num_rows > 0) {
    $row = $result_user->fetch_assoc();
    $role = $row['role'];
    $enseignant_id = $row['id'];
} else {
    header("Location: login.php");
    exit();
}

if ($role !== 'enseignant') {
    header("Location: unauthorized.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titre_seance = $_POST['titre_seance'];
    $date_seance = $_POST['date_seance'];
    $duree_seance = $_POST['duree_seance'];
    $commentaire_seance = $_POST['commentaire_seance'];

    $sql_seance = "INSERT INTO seances (titre, date_seance, duree, commentaire, enseignant_id) 
                   VALUES ('$titre_seance', '$date_seance', '$duree_seance', '$commentaire_seance', '$enseignant_id')";
    
    if ($conn->query($sql_seance) === TRUE) {
        echo "<script>alert('Séance créée avec succès'); window.location.href = 'dashboard_enseignant.php';</script>";
    } else {
        echo "Erreur : " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajouter une Séance</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f4f7f8;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="date"],
        input[type="time"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccd0d5;
            border-radius: 6px;
            font-size: 15px;
            transition: border-color 0.3s;
        }

        input:focus,
        textarea:focus {
            border-color: #007bff;
            outline: none;
        }

        textarea {
            resize: vertical;
            min-height: 80px;
        }

        .btn-success {
            background-color: #28a745;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
            width: 100%;
        }

        .btn-success:hover {
            background-color: #218838;
        }

        @media (max-width: 640px) {
            .container {
                margin: 20px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Ajouter une Séance de Cours</h1>
        <form method="POST" action="ajouter_seance.php">
            <div class="form-group">
                <label for="titre_seance">Titre de la Séance :</label>
                <input type="text" name="titre_seance" required>
            </div>
            <div class="form-group">
                <label for="date_seance">Date de la Séance :</label>
                <input type="date" name="date_seance" required>
            </div>
            <div class="form-group">
                <label for="duree_seance">Durée de la Séance :</label>
                <input type="time" name="duree_seance" required>
            </div>
            <div class="form-group">
                <label for="commentaire_seance">Commentaire :</label>
                <textarea name="commentaire_seance"></textarea>
            </div>
            <button type="submit" class="btn-success">Ajouter la Séance</button>
        </form>
    </div>
</body>
</html>
