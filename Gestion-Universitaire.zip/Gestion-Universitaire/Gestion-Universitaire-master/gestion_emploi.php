<?php

ini_set('display_errors', 1); // Affiche les erreurs
ini_set('display_startup_errors', 1); // Affiche les erreurs au démarrage
error_reporting(E_ALL); // Affiche toutes les erreurs

include('connexion.php');
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Récupération des classes depuis la table `classes` (avec S !)
$sql_classes = "SELECT id AS id_classe, nom AS nom_classe FROM classe";
$result_classes = $conn->query($sql_classes);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Emploi du Temps</title>
    <style>
        /* Global Styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            color: #ffffff;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            margin-top: 40px;
            font-size: 2.5rem;
            color: #f5f5f5;
            text-align: center;
            font-weight: 700;
        }

        h3 {
            font-size: 1.8rem;
            color: #fff;
            margin-top: 30px;
            font-weight: 600;
        }

        .container {
            width: 80%;
            max-width: 1200px;
            margin-top: 40px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 2px solid #444;
            color: #f5f5f5;
        }

        th {
            background-color: #00c9a7;
            color: #fff;
            font-size: 1.1rem;
        }

        tr:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }

        td {
            font-size: 1rem;
        }

        .no-data {
            color: #d4d4d4;
            font-size: 1.2rem;
            text-align: center;
        }

        /* Media Queries for mobile */
        @media (max-width: 768px) {
            .container {
                width: 95%;
                padding: 20px;
            }

            h2 {
                font-size: 2rem;
            }

            h3 {
                font-size: 1.6rem;
            }

            th, td {
                padding: 10px;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>

    <h2>Gestion des Emplois du Temps</h2>

    <div class="container">
        <?php while ($classe = $result_classes->fetch_assoc()) : ?>
            <h3>Classe : <?php echo htmlspecialchars($classe['nom_classe'] ?? 'Nom inconnu'); ?></h3>

            <?php
            $id_classe = $classe['id_classe'];
            $sql_emploi = "SELECT * FROM emplois_du_temps 
                           WHERE id_classe = $id_classe 
                           ORDER BY 
                           FIELD(jour, 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi'),
                           heure_debut";
            $result_emploi = $conn->query($sql_emploi);
            ?>

            <?php if ($result_emploi->num_rows > 0): ?>
                <table>
    <thead>
        <tr>
            <th>Jour</th>
            <th>Heure Début</th>
            <th>Heure Fin</th>
            <th>Matière</th>
            <th>Salle</th>
            <th>Actions</th> <!-- Nouvelle colonne -->
        </tr>
    </thead>
    <tbody>
        <?php while ($emploi = $result_emploi->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($emploi['jour']); ?></td>
                <td><?php echo substr($emploi['heure_debut'], 0, 5); ?></td>
                <td><?php echo substr($emploi['heure_fin'], 0, 5); ?></td>
                <td><?php echo htmlspecialchars($emploi['matiere']); ?></td>
                <td><?php echo htmlspecialchars($emploi['salle']); ?></td>
                <td>
                    <a href="modifier_emploi.php?id=<?php echo $emploi['id']; ?>" 
                       style="color: #00c9a7; font-weight: bold; text-decoration: underline;">
                       Modifier
                    </a>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

            <?php else: ?>
                <p class="no-data">Aucun emploi du temps pour cette classe.</p>
            <?php endif; ?>
            <hr style="border: 1px solid #444;"/>
        <?php endwhile; ?>
    </div>

</body>
</html>
