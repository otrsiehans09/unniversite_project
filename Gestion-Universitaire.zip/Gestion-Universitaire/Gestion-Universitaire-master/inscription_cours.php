<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['email'];
include('connexion.php');

$sql_fetch_user = "SELECT * FROM accounts WHERE email='$email'";
$result_user = $conn->query($sql_fetch_user);

if ($result_user->num_rows > 0) {
    $row = $result_user->fetch_assoc();
    $role = $row['role'];

    if ($role !== 'etudiant') {
        header("Location: unauthorized.php"); 
        exit();
    }
}

$id_etudiant = $row['id']; // L'ID de l'étudiant connecté

if (isset($_GET['id_cours'])) {
    $id_cours = $_GET['id_cours'];

    // Vérifier si l'étudiant est déjà inscrit à ce cours
    $check_inscription = "SELECT * FROM `inscriptions` WHERE `id_etudiant` = '$id_etudiant' AND `id_cours` = '$id_cours'";
    $inscription_res = $conn->query($check_inscription);
    
    if ($inscription_res->num_rows === 0) {
        // Inscrire l'étudiant au cours
        $sql_insert = "INSERT INTO `inscriptions` (`id_etudiant`, `id_cours`) VALUES ('$id_etudiant', '$id_cours')";
        if ($conn->query($sql_insert) === TRUE) {
            header("Location: cours.php?message=Inscription réussie");
        } else {
            echo "Erreur : " . $conn->error;
        }
    } else {
        echo "Vous êtes déjà inscrit à ce cours.";
    }
}
?>
