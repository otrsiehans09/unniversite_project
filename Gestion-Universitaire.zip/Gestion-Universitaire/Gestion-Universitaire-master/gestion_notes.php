<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

include('connexion.php');

$email = $_SESSION['email'];
$sql_fetch_user = "SELECT * FROM accounts WHERE email='$email'";
$result_user = $conn->query($sql_fetch_user);

if ($result_user->num_rows > 0) {
    $row = $result_user->fetch_assoc();
    $role = $row['role'];
    $enseignant_id = $row['id']; // Récupérer l'ID de l'enseignant connecté
} else {
    header("Location: login.php");
    exit();
}

if ($role !== 'enseignant') {
    header("Location: unauthorized.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $etudiant_id = $_POST['etudiant_id'];
    $note = $_POST['note'];
    $matiere = $_POST['matiere'];

    $sql_note = "INSERT INTO notes (id_etudiant, id_cours, note, enseignant_id) 
                 VALUES ('$etudiant_id', '$matiere', '$note', '$enseignant_id')";
    
    if ($conn->query($sql_note) === TRUE) {
        echo "<script>alert('Note attribuée avec succès'); window.location.href = 'dashboard_enseignant.php';</script>";
    } else {
        echo "Erreur : " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: linear-gradient(135deg, #667eea, #764ba2);
        margin: 0;
        padding: 0;
        color: #fff;
    }

    .container {
        max-width: 600px;
        margin: 60px auto;
        padding: 30px;
        background-color: rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
        backdrop-filter: blur(8px);
    }

    h1 {
        text-align: center;
        margin-bottom: 30px;
        font-size: 28px;
        color: #f0f0f0;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #f8f8f8;
    }

    .form-control {
        width: 100%;
        padding: 12px 15px;
        border: none;
        border-radius: 8px;
        background-color: rgba(255, 255, 255, 0.15);
        color: #fff;
        font-size: 16px;
        transition: background-color 0.3s ease;
    }

    .form-control:focus {
        outline: none;
        background-color: rgba(255, 255, 255, 0.25);
    }

    .btn {
        display: block;
        width: 100%;
        padding: 12px;
        font-size: 16px;
        font-weight: bold;
        text-align: center;
        background-color: #00c9a7;
        color: white;
        border: none;
        border-radius: 10px;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .btn:hover {
        background-color: #00b39f;
        transform: translateY(-2px);
    }

    @media screen and (max-width: 600px) {
        .container {
            margin: 30px 15px;
            padding: 20px;
        }

        h1 {
            font-size: 22px;
        }
    }
</style>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Notes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Attribuer des Notes</h1>
        <form method="POST" action="gestion_notes.php">
            <div class="form-group">
                <label for="etudiant_id">ID de l'Étudiant :</label>
                <input type="text" class="form-control" name="etudiant_id" required>
            </div>
            <div class="form-group">
                <label for="matiere">Matière :</label>
                <input type="text" class="form-control" name="matiere" required>
            </div>
            <div class="form-group">
                <label for="note">Note :</label>
                <input type="number" class="form-control" name="note" required>
            </div>
            <button type="submit" class="btn btn-success">Attribuer la Note</button>
        </form>
    </div>
</body>
</html>
