<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

include('connexion.php');

// Récupération des infos de l'utilisateur connecté
$email = $_SESSION['email'];
$sql_fetch_user = "SELECT * FROM accounts WHERE email='$email'";
$result_user = $conn->query($sql_fetch_user);

if ($result_user->num_rows > 0) {
    $row = $result_user->fetch_assoc();
    $role = $row['role'];
    $enseignant_id = $row['id'];
} else {
    header("Location: login.php");
    exit();
}

// Vérifie si l'utilisateur est un enseignant
if ($role !== 'enseignant') {
    header("Location: unauthorized.php");
    exit();
}

// Traitement du formulaire
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titre_examen = $_POST['titre_examen'];
    $date_examen = $_POST['date_examen'];

    $target_dir = "uploads/examens/";
    $fichier_examen = basename($_FILES['fichier_examen']['name']);
    $target_file = $target_dir . $fichier_examen;

    // Créer le dossier s'il n'existe pas
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Envoi du fichier
    if (move_uploaded_file($_FILES["fichier_examen"]["tmp_name"], $target_file)) {
        $sql_examen = "INSERT INTO examens (titre, date_examen, fichier, enseignant_id) 
                       VALUES ('$titre_examen', '$date_examen', '$fichier_examen', '$enseignant_id')";

        if ($conn->query($sql_examen) === TRUE) {
            echo "<script>alert('Examen déposé avec succès'); window.location.href = 'dashboard_enseignant.php';</script>";
        } else {
            echo "Erreur base de données : " . $conn->error;
        }
    } else {
        echo "Erreur lors de l'envoi du fichier.";
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Déposer un Examen</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: "Segoe UI", sans-serif;
            background: linear-gradient(135deg, #ff416c, #ff4b2b);
            color: #ffffff;
            min-height: 100vh;
        }

        .container {
            max-width: 600px;
            margin: 60px auto;
            background-color: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 32px;
            color: #f5f5f5;
            font-weight: 700;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #e0e0e0;
        }

        .form-control {
            width: 100%;
            padding: 15px 20px;
            border-radius: 10px;
            border: none;
            background-color: rgba(255, 255, 255, 0.2);
            color: #fff;
            font-size: 16px;
            transition: background 0.3s ease;
        }

        .form-control::file-selector-button {
            background-color: #ffffff30;
            color: #ffffff;
            border: none;
            padding: 10px 15px;
            border-radius: 6px;
            cursor: pointer;
        }

        .form-control:focus {
            outline: none;
            background-color: rgba(255, 255, 255, 0.3);
        }

        button {
            background-color: #00c9a7;
            color: white;
            border: none;
            padding: 15px 20px;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
            width: 100%;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        button:hover {
            background-color: #00b39f;
            transform: translateY(-2px);
        }

        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #e0e0e0;
        }

        .footer a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        /* Responsiveness */
        @media (max-width: 600px) {
            .container {
                margin: 30px 15px;
                padding: 30px;
            }

            h1 {
                font-size: 26px;
            }
        }

    </style>
</head>
<body>
    <div class="container">
        <h1>Déposer un Examen</h1>
        <form method="POST" action="deposer_examen.php" enctype="multipart/form-data">
            <div class="form-group">
                <label for="titre_examen">Titre de l'Examen :</label>
                <input type="text" class="form-control" name="titre_examen" required>
            </div>
            <div class="form-group">
                <label for="date_examen">Date de l'Examen :</label>
                <input type="date" class="form-control" name="date_examen" required>
            </div>
            <div class="form-group">
                <label for="fichier_examen">Fichier de l'Examen :</label>
                <input type="file" class="form-control" name="fichier_examen" required>
            </div>
            <button type="submit">Déposer l'Examen</button>
        </form>
    </div>

    <div class="footer">
        <p>© 2025 Gestion des Examens - <a href="dashboard_enseignant.php">Retour au tableau de bord</a></p>
    </div>
</body>
</html>
