<?php
// profil_etudiant.php

include('connexion.php');  // Inclure la connexion à la base de données
session_start();  // Commencer la session si ce n'est pas déjà fait

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['email'];
$sql_fetch_user = "SELECT * FROM accounts WHERE email='$email'";
$result_user = $conn->query($sql_fetch_user);
$row = $result_user->fetch_assoc();

$role = $row['role'];
$nom = $row['nom'];
$prenom = $row['prenom'];
$date_naissance = $row['date_naissance'];
$numero_tel = $row['numero_tel']; // Si tu veux ajouter un numéro de téléphone, sinon enlève cette ligne
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Profil</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
        }

        /* Conteneur principal pour la sidebar et le contenu */
        .wrapper {
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100%;
            background-color: #2c3e50; /* Même couleur que dans les autres pages */
            color: white;
            padding-top: 20px;
            z-index: 1000;
            box-shadow: 2px 0px 8px rgba(0, 0, 0, 0.2);
        }

        .sidebar .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar .logo a {
            font-size: 20px;
            color: white;
            font-weight: bold;
        }

        .sidebar .nav {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .sidebar .nav li {
            width: 100%;
        }

        .sidebar .nav li a {
            display: block;
            color: white;
            padding: 15px 20px;
            text-decoration: none;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .sidebar .nav li a:hover {
            background-color: #1abc9c; /* Changement de couleur au survol */
        }

        .sidebar .nav .active a {
            background-color: #34495e; /* Color active */
        }

        /* Contenu principal */
        .main-panel {
            margin-left: 250px;
            padding: 20px;
            width: calc(100% - 250px);
        }

        .container {
            width: 80%;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }

        .profile-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .profile-info div {
            font-size: 16px;
            color: #333;
            padding: 10px;
        }

        .btn {
            display: block;
            width: 200px;
            margin: 30px auto;
            padding: 10px;
            text-align: center;
            background-color: #6c5ce7;
            color: #fff;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #5a4dc6;
        }
    </style>
</head>
<body>

<!-- Barre de navigation -->
<nav class="navbar navbar-default navbar-fixed">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a href="#">
                        <p><?php echo $prenom . ' ' . $nom; ?></p>
                    </a>
                </li>

                <li>
                    <a href="logout.php">
                        <p>Déconnexion</p>
                    </a>
                </li>
                <li class="separator hidden-lg"></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Wrapper principal pour la sidebar et le contenu -->
<div class="wrapper">
    <!-- Sidebar -->
    <?php include('sidenav.php'); ?>

    <!-- Contenu principal -->
    <div class="main-panel">
        <div class="container">
            <h1>Mon Profil</h1>

            <div class="profile-info">
                <div><strong>Nom :</strong> <?php echo $prenom . ' ' . $nom; ?></div>
                <div><strong>Email :</strong> <?php echo $email; ?></div>
            </div>
            <div class="profile-info">
                <div><strong>Date de naissance :</strong> <?php echo $date_naissance; ?></div>
                <div><strong>Numéro de téléphone :</strong> <?php echo $numero_tel ? $numero_tel : 'Non renseigné'; ?></div>
            </div>

            <a href="modifier_profil.php" class="btn">Modifier mon profil</a>
        </div>
    </div>
</div>

<!-- Scripts pour la gestion de la navbar -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html>
