<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

include('connexion.php');

// Vérifie si l'utilisateur a le bon rôle pour accéder à cette page
if ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'enseignant') {
    echo "Accès non autorisé. Vous n'êtes pas autorisé à accéder à cette page. Veuillez contacter l'administrateur.";
    echo '<br><a href="index.php">Retour à la page d\'accueil</a>';
    exit();
}

$email = $_SESSION['email'];
$sql_fetch_user = "SELECT * FROM accounts WHERE email='$email'";
$result_user = $conn->query($sql_fetch_user);

if ($result_user->num_rows > 0) {
    $row = $result_user->fetch_assoc();
    $role = $row['role'];
    $enseignant_id = $row['id'];
} else {
    header("Location: login.php");
    exit();
}

if ($role !== 'enseignant') {
    header("Location: unauthorized.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord Enseignant</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/animate.min.css" rel="stylesheet"/>
    <link href="assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Sidenavigation et autres éléments restent inchangés */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
        }

        body {
            display: flex;
            min-height: 100vh;
            background: linear-gradient(135deg, #4e54c8, #8f94fb);
            color: #fff;
            margin: 0;
        }

        /* Sidebar */
        .sidenav {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: rgba(0, 0, 0, 0.1);
            padding-top: 20px;
            padding-left: 20px;
            box-shadow: 2px 0px 15px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
            transition: all 0.3s ease;
        }

        .sidenav ul {
            list-style-type: none;
            padding: 0;
        }

        .sidenav ul li {
            margin: 20px 0;
        }

        .sidenav ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
            padding: 12px 15px;
            border-radius: 5px;
            display: block;
            transition: background-color 0.3s ease;
            white-space: nowrap;
        }

        .sidenav ul li a:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .sidenav .active {
            background-color: #4e54c8;
        }

        /* Dynamique : Accordéon */
        .menu-item {
            cursor: pointer;
            font-weight: bold;
            padding: 12px 15px;
            border-radius: 5px;
            background-color: rgba(255, 255, 255, 0.1);
            margin-bottom: 10px;
            transition: background-color 0.3s ease;
        }

        .menu-item:hover {
            background-color: rgba(255, 255, 255, 0.3);
        }

        .submenu {
            list-style-type: none;
            padding-left: 20px;
            display: none;
        }

        .submenu li {
            margin-bottom: 10px;
        }

        .submenu li a {
            font-size: 0.9rem;
            padding: 10px 20px;
            color: #fff;
            display: block;
            transition: background-color 0.3s ease;
        }

        .submenu li a:hover {
            background-color: rgba(255, 255, 255, 0.3);
        }

        /* Main content */
        .main-content {
            margin-left: 270px;
            padding: 40px;
            background-color: rgba(255, 255, 255, 0.1);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            border-radius: 15px;
        }

        .dashboard-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 30px;
        }

        .action {
            background-color: rgba(255, 255, 255, 0.15);
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .btn {
            display: inline-block;
            background-color: #fff;
            color: #4e54c8;
            padding: 10px 20px;
            text-decoration: none;
            font-weight: bold;
            border-radius: 8px;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .btn:hover {
            background-color: #ddd;
            transform: scale(1.05);
        }

        /* Responsive */
        @media screen and (max-width: 768px) {
            .sidenav {
                width: 100%;
                height: auto;
                position: relative;
            }

            .main-content {
                margin-left: 0;
                padding: 20px;
            }

            .dashboard-actions {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

    <!-- Sidenav -->
    <div class="sidenav">
        <ul>
            <li><a href="dashboard_enseignant.php" class="active">Accueil</a></li>
            <li class="menu-item" id="seances">Gestion des Séances</li>
            <ul class="submenu" id="submenu_seances">
                <li><a href="ajouter_seance.php">Ajouter Séance</a></li>
                <li><a href="liste_seances.php">Liste Séances</a></li>
            </ul>
            <li><a href="gestion_notes.php">Gestion des Notes</a></li>
            <li><a href="deposer_examen.php">Déposer un Examen</a></li>
            <li><a href="profil_enseignant.php">Profil</a></li>
            <li><a href="logout.php">Se Déconnecter</a></li>
        </ul>
    </div>

    <!-- Main content -->
    <div class="main-content">
        <h1>Bienvenue, <?php echo $row['nom'] . ' ' . $row['prenom']; ?> !</h1>

        <div class="dashboard-actions">
            <div class="action">
                <h2>Créer une Séance de Cours</h2>
                <a href="ajouter_seance.php" class="btn">Créer une Séance</a>
            </div>

            <div class="action">
                <a href="gestion_notes.php" class="btn">Gérer les Notes</a>
            </div>

            <div class="action">
                <h2>Déposer un Examen</h2>
                <a href="deposer_examen.php" class="btn">Déposer un Examen</a>
            </div>

            <div class="action">
                <h2>Mettre à Jour le Profil</h2>
                <a href="profil_enseignant.php" class="btn">Mon Profil</a>
            </div>
        </div>
    </div>

    <script>
        // Fonction pour gérer l'accordéon
        document.getElementById("seances").addEventListener("click", function() {
            var submenu = document.getElementById("submenu_seances");
            submenu.style.display = submenu.style.display === "block" ? "none" : "block";
        });
    </script>

</body>
</html>

<?php $conn->close(); ?>
