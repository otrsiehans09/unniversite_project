<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['role'] != 'etudiant') {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['email'];
include('connexion.php');

// Infos étudiant
$sql_fetch_user = "SELECT * FROM accounts WHERE email='$email'";
$result_user = $conn->query($sql_fetch_user);
if ($result_user->num_rows > 0) {
    $row = $result_user->fetch_assoc();
    $etudiant_id = $row['id'];
    $etudiant_nom = $row['nom'];
    $etudiant_prenom = $row['prenom'];
}
?>

<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Étudiant</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include('index.css'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .section {
            margin-bottom: 40px;
        }

        .section h3 {
            font-size: 22px;
            margin-bottom: 20px;
            color: #2f3b52;
        }

        .row {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .card {
            background: #fff;
            border-left: 5px solid #3498db;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0,0,0,0.1);
            flex: 1 1 300px;
            transition: transform 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-title {
            font-weight: bold;
            font-size: 18px;
            color: #333;
        }

        .btn {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 18px;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background: #2980b9;
        }

        #edt-section {
            display: none;
            margin-top: 20px;
        }

        .section-toggle {
            margin-top: 20px;
        }

    </style>
</head>

<body>
    <div class="wrapper">
        <?php include('sidenav.php'); ?>

        <div class="main-panel">
            <?php include('navtop.php'); ?>

            <div class="content">
                <div class="container-fluid">
                    <h2>👋 Bienvenue, <?php echo $etudiant_prenom . ' ' . $etudiant_nom; ?> !</h2>

                    <!-- COURSES -->
                    <div class="section">
                        <h3>📘 Cours auxquels vous êtes inscrit</h3>
                        <div class="row">
                            <?php
                            $sql_courses = "SELECT cours.titre FROM cours 
                                            JOIN inscriptions ON cours.id = inscriptions.id_cours 
                                            WHERE inscriptions.id_etudiant = $etudiant_id";
                            $result_courses = $conn->query($sql_courses);
                            if ($result_courses->num_rows > 0) {
                                while ($course = $result_courses->fetch_assoc()) {
                                    echo "<div class='card'><div class='card-title'>" . $course['titre'] . "</div></div>";
                                }
                            } else {
                                echo "<div class='card'>Aucun cours inscrit.</div>";
                            }
                            ?>
                        </div>
                    </div>

                    <!-- NOTES -->
                    <div class="section">
                        <h3>📝 Vos Notes</h3>
                        <div class="row">
                            <?php
                            $sql_notes = "SELECT cours.titre, notes.note FROM notes 
                                          JOIN cours ON notes.id_cours = cours.id 
                                          WHERE notes.id_etudiant = $etudiant_id";
                            $result_notes = $conn->query($sql_notes);
                            if ($result_notes->num_rows > 0) {
                                while ($note = $result_notes->fetch_assoc()) {
                                    echo "<div class='card'><strong>" . $note['titre'] . "</strong><br>Note : " . $note['note'] . "</div>";
                                }
                            } else {
                                echo "<div class='card'>Aucune note disponible.</div>";
                            }
                            ?>
                        </div>
                    </div>

                    <!-- QUESTIONS -->
                    <div class="section">
                        <h3>💬 Vos Questions</h3>
                        <div class="row">
                            <?php
                            $sql_questions = "SELECT * FROM questions WHERE id_etudiant = $etudiant_id ORDER BY date_creation DESC";
                            $result_questions = $conn->query($sql_questions);
                            if ($result_questions->num_rows > 0) {
                                while ($question = $result_questions->fetch_assoc()) {
                                    echo "<div class='card'><strong>" . $question['question'] . "</strong><br>Statut : " . $question['statut'] . "</div>";
                                }
                            } else {
                                echo "<div class='card'>Aucune question posée.</div>";
                            }
                            ?>
                            <a href="poser_question.php" class="btn">➕ Poser une question</a>
                        </div>
                    </div>

                    <!-- BOUTON AFFICHER E.D.T -->
                    <div class="section-toggle">
    <a href="emploi.php" class="btn">📆 Consulter mon Emploi du Temps</a>
</div>

                    <!-- EMPLOI DU TEMPS -->
                    <div id="edt-section" class="section">
                        <h3>📆 Emploi du Temps</h3>
                        <div class="row">
                            <?php
                            $sql_edt = "SELECT cours.titre, emploi_du_temps.jour, emploi_du_temps.heure 
                                        FROM emploi_du_temps 
                                        JOIN cours ON emploi_du_temps.id_cours = cours.id 
                                        JOIN inscriptions ON inscriptions.id_cours = cours.id 
                                        WHERE inscriptions.id_etudiant = $etudiant_id
                                        ORDER BY FIELD(jour, 'Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'), heure";
                            $result_edt = $conn->query($sql_edt);
                            if ($result_edt->num_rows > 0) {
                                while ($edt = $result_edt->fetch_assoc()) {
                                    echo "<div class='card'><strong>" . $edt['titre'] . "</strong><br>" . $edt['jour'] . " à " . $edt['heure'] . "</div>";
                                }
                            } else {
                                echo "<div class='card'>Aucun emploi du temps trouvé.</div>";
                            }
                            ?>
                        </div>
                    </div>

                </div>
            </div>

            <?php include('footer.php'); ?>
        </div>
    </div>

    <!-- JS Toggle -->
    <script>
        function toggleEDT() {
            var section = document.getElementById("edt-section");
            section.style.display = section.style.display === "none" ? "block" : "none";
        }
    </script>
</body>
</html>
