<?php
session_start();
include('connexion.php');

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$email_connecte = $_SESSION['email'];
$sql_fetch_user = "SELECT * FROM accounts WHERE email = ?";
$stmt = $conn->prepare($sql_fetch_user);
$stmt->bind_param("s", $email_connecte);
$stmt->execute();
$result_user = $stmt->get_result();

if ($result_user->num_rows > 0) {
    $row = $result_user->fetch_assoc();
    $role = $row['role'];

    if ($role !== 'admin') {
        header("Location: unauthorized.php");
        exit();
    }
}

// Récupérer les données à partir de la base de données
$query_etudiants = "SELECT COUNT(*) as total_etudiants FROM accounts WHERE role='etudiant'";
$result_etudiants = $conn->query($query_etudiants);
$row_etudiants = mysqli_fetch_assoc($result_etudiants);
$total_etudiants = $row_etudiants['total_etudiants'];

$query_enseignants = "SELECT COUNT(*) as total_enseignants FROM enseignant";
$result_enseignants = $conn->query($query_enseignants);
$row_enseignants = mysqli_fetch_assoc($result_enseignants);
$total_enseignants = $row_enseignants['total_enseignants'];

$query_departements = "SELECT COUNT(*) as total_departements FROM departement";
$result_departements = $conn->query($query_departements);
$row_departements = mysqli_fetch_assoc($result_departements);
$total_departements = $row_departements['total_departements'];

$query_specialites = "SELECT COUNT(*) as total_specialites FROM specialite";
$result_specialites = $conn->query($query_specialites);
$row_specialites = mysqli_fetch_assoc($result_specialites);
$total_specialites = $row_specialites['total_specialites'];

$query_classes = "SELECT COUNT(*) as total_classes FROM classe";
$result_classes = $conn->query($query_classes);
$row_classes = mysqli_fetch_assoc($result_classes);
$total_classes = $row_classes['total_classes'];

$query_cours = "SELECT COUNT(*) as total_cours FROM cours";
$result_cours = $conn->query($query_cours);
$row_cours = mysqli_fetch_assoc($result_cours);
$total_cours = $row_cours['total_cours'];
?>
<!doctype html>
<html lang="en">

<head>
    <?php include('index.css'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>
    <div class="wrapper">
        <?php include('sidenav.php'); ?>

        <div class="main-panel">
            <?php include('navtop.php'); ?>

            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-10">
                            <div class="card">
                                <div class="content">
                                    <canvas id="myChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php include('footer.php'); ?>
        </div>
    </div>

    <script>
        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Etudiants', 'Enseignants', 'Départements', 'Spécialités', 'Classes', 'Cours'],
                datasets: [{
                    label: ' ',
                    data: [<?php echo $total_etudiants; ?>, <?php echo $total_enseignants; ?>, <?php echo $total_departements; ?>, <?php echo $total_specialites; ?>, <?php echo $total_classes; ?>, <?php echo $total_cours; ?>],
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

    <h2>Mes Notes</h2>
    <table>
        <tr>
            <th>Cours</th>
            <th>Note</th>
            <th>Commentaire</th>
        </tr>
        <?php
        $sql_notes = "SELECT n.id_cours, n.note, n.commentaire, c.titre FROM notes n JOIN cours c ON n.id_cours = c.id WHERE n.id_etudiant = ?";
        $stmt_notes = $conn->prepare($sql_notes);
        $stmt_notes->bind_param("i", $id_etudiant); // Make sure $id_etudiant is defined before this
        $stmt_notes->execute();
        $res_notes = $stmt_notes->get_result();
        while ($note = $res_notes->fetch_assoc()) {
        ?>
            <tr>
                <td><?php echo htmlspecialchars($note['titre']); ?></td>
                <td><?php echo htmlspecialchars($note['note']); ?></td>
                <td><?php echo htmlspecialchars($note['commentaire']); ?></td>
            </tr>
        <?php } ?>
    </table>
</body>

<?php include('index.js'); ?>

</html>