<?php
// questions.php

include('connexion.php');  // Inclure la connexion à la base de données
session_start();  // Commencer la session si ce n'est pas déjà fait

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['email'];
$sql_fetch_user = "SELECT * FROM accounts WHERE email='$email'";
$result_user = $conn->query($sql_fetch_user);
$row = $result_user->fetch_assoc();
$role = $row['role'];

// Vérifier si l'utilisateur est un étudiant
if ($role !== 'etudiant') {
    echo "Accès interdit.";
    exit();
}

// Récupérer les questions de l'étudiant
$sql = "SELECT * FROM questions WHERE id_etudiant = (SELECT id FROM accounts WHERE email = '$email')";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Questions</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>

.btn-delete {
    display: inline-block;
    padding: 6px 12px;
    background-color: #e74c3c;
    color: white;
    border-radius: 5px;
    text-decoration: none;
    font-weight: 500;
    transition: background-color 0.3s ease;
    font-size: 14px;
}

.btn-delete:hover {
    background-color: #c0392b;
}

        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
        }
        /* Conteneur principal pour la sidebar et le contenu */
        .wrapper {
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100%;
            background-color:rgb(2, 19, 255); /* Même couleur que dans les autres pages */
            color: white;
            padding-top: 20px;
            z-index: 1000;
            box-shadow: 2px 0px 8px rgba(0, 0, 0, 0.2);
        }

        .sidebar .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar .logo a {
            font-size: 20px;
            color: white;
            font-weight: bold;
        }

        .sidebar .nav {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .sidebar .nav li {
            width: 100%;
        }

        .sidebar .nav li a {
            display: block;
            color: white;
            padding: 15px 20px;
            text-decoration: none;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .sidebar .nav li a:hover {
            background-color: #1abc9c; /* Changement de couleur au survol */
        }

        .sidebar .nav .active a {
            background-color: #34495e; /* Color active */
        }

        /* Contenu principal */
        .main-panel {
            margin-left: 250px;
            padding: 20px;
            width: calc(100% - 250px);
        }

        .container {
            width: 80%;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #6c5ce7;
            color: #fff;
            font-weight: 600;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .btn {
            display: block;
            width: 200px;
            margin: 30px auto;
            padding: 10px;
            text-align: center;
            background-color: #6c5ce7;
            color: #fff;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color:rgb(24, 0, 238);
        }

        .status {
            padding: 5px 10px;
            border-radius: 5px;
            font-weight: 500;
        }

        .status.en-attente {
            background-color: #f39c12;
            color: white;
        }

        .status.repondu {
            background-color: #27ae60;
            color: white;
        }
    </style>
</head>
<body>

<!-- Wrapper principal pour la sidebar et le contenu -->
<div class="wrapper">
    <!-- Sidebar -->
    <?php include('sidenav.php'); ?>

    <!-- Contenu principal -->
    <div class="main-panel">
        <div class="container">
            <h1>Mes Questions</h1>
            
            <table>
                <tr>
                    <th>Question</th>
                    <th>Statut</th>
                    <th>Date</th>
                </tr>

                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['question']; ?></td>
                        <td><span class="status <?php echo ($row['statut'] == 'en attente') ? 'en-attente' : 'repondu'; ?>"><?php echo $row['statut']; ?></span></td>
                        <td><?php echo $row['date_creation']; ?></td>
                    </tr>
                    <td>
                    <a href="supprimer_question.php?id_question=<?php echo $row['id']; ?>" 
   class="btn-delete" 
   onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette question ?');">
   🗑 Supprimer
</a>

                     </td>
                     </tr>
                <?php endwhile; ?>
            </table>
            <a href="poser_question.php" class="btn">Poser une nouvelle question</a>
        </div>
    </div>
</div>

</body>
</html>
