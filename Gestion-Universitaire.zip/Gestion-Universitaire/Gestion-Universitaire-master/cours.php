<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['email'];

include('connexion.php');

$sql_fetch_user = "SELECT * FROM accounts WHERE email = ?";
$stmt = $conn->prepare($sql_fetch_user);
$stmt->bind_param("s", $email);
$stmt->execute();
$result_user = $stmt->get_result();

if ($result_user->num_rows > 0) {
    $row = $result_user->fetch_assoc();
    $role = $row['role'];

    if ($role !== 'etudiant') {
        header("Location: unauthorized.php");
        exit();
    }
}

$id_etudiant = $row['id']; // L'ID de l'étudiant connecté
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include('index.css'); ?>
    <style>
        .swal2-popup {
            font-size: 14px !important;
        }

        .modal-backdrop.in {
            opacity: 0 !important;
        }
    </style>
</head>

<body>

    <div class="wrapper">
        <?php include('sidenav.php'); ?>

        <div class="main-panel">
            <?php include('navtop.php'); ?>

            <br />

            <div class="content">
                <div class="container-fluid">
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="content table-responsive table-full-width">
                                    <table class="table table-hover table-striped">
                                        <thead>
                                            <tr>
                                                <th>Cours</th>
                                                <th>Date d'ajout</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $sqlfetsh = "SELECT * FROM `cours` ORDER BY id ASC";
                                            $res = $conn->query($sqlfetsh);
                                            while ($row = $res->fetch_assoc()) {
                                                // Vérification si l'étudiant est déjà inscrit
                                                $cours_id = $row['id'];
                                                $check_inscription = "SELECT * FROM `inscriptions` WHERE `id_etudiant` = ? AND `id_cours` = ?";
                                                $stmt_check = $conn->prepare($check_inscription);
                                                $stmt_check->bind_param("ii", $id_etudiant, $cours_id);
                                                $stmt_check->execute();
                                                $inscription_res = $stmt_check->get_result();
                                                $already_registered = ($inscription_res->num_rows > 0);
                                            ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($row['titre']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['date_creation']); ?></td>
                                                    <td>
                                                        <?php if ($already_registered) { ?>
                                                            <button class="btn btn-success btn-fill" disabled>Inscrit</button>
                                                        <?php } else { ?>
                                                            <a href="inscription_cours.php?id_cours=<?php echo htmlspecialchars($row['id']); ?>" class="btn btn-primary btn-fill">S'inscrire</a>
                                                        <?php } ?>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php include('footer.php'); ?>

        </div>
    </div>

</body>
<?php include('index.js'); ?>

</html>